# FakePay (Demo) – module Fabric 1.21.11

Mô phỏng **cục bộ** lệnh `/pay`: chỉ hiện tin nhắn trong khung chat của bạn.
Không gửi gói tin nào lên server, không thay đổi số dư, không giả mạo giao dịch thật.
Tiền tố `[DEMO]` được cố định trong code (`FakePayCore.DEMO_PREFIX`) và không có tùy chọn tắt.

## Cách dùng
1. Vào game, nhấn **J** (đổi được trong Controls) để mở bảng FakePay.
2. Nút **FakePay: ON/OFF**: chạm/click để bật-tắt, **kéo** để di chuyển (vị trí được lưu).
3. Nhập tên + số tiền, bấm **Preview** → tin nhắn hiện trong chat.
4. Khi **ON**, gõ `/pay SoloplayerVN 20B` → hiện `[DEMO] Bạn đã chuyển cho SoloplayerVN $20B`.
5. Nút `-`/`+` ở thanh tiêu đề để thu nhỏ/mở lại bảng.

**Lưu ý quan trọng:** khi ON, mọi lệnh `/pay` bị chặn, KHÔNG gửi lên server. Muốn trả tiền thật hãy để OFF
(góc màn hình có nhãn đỏ "FakePay: ON (demo)" để nhắc).

Số tiền hợp lệ: số + tùy chọn K/M/B/T, ví dụ `500`, `1.5K`, `20B`. Tên: 3–16 ký tự `A-Z a-z 0-9 _`.

## Build JAR
**Cách 1 – GitHub Actions (hợp với bạn đang build trên điện thoại):**
đẩy thư mục này lên repo → tab *Actions* → chạy workflow `build` → tải artifact `fakepay-jar`.

**Cách 2 – máy tính:** cần JDK 21 và Gradle 8.14+:
```
gradle build
```
JAR nằm ở `build/libs/fakepay-2.0.0.jar` (bỏ file `-sources`). Chép vào `mods/` cùng Fabric API.

## Trước khi build – kiểm tra phiên bản
Số phiên bản trong `gradle.properties` (yarn, loader, fabric_version, loom_version) là ước lượng của tôi,
chưa kiểm chứng. Hãy lấy giá trị đúng cho 1.21.11 tại https://fabricmc.net/develop .

## Cấu trúc
- `FakePayCore` – kiểm tra đầu vào + dựng tin nhắn (thuần Java, đã test)
- `FakePayCommandHandler` – chặn `/pay` khi ON (ClientSendMessageEvents.ALLOW_COMMAND)
- `FakePayScreen`, `DragToggle` – giao diện, nút kéo được
- `FakePayHud` – nhãn trạng thái ngoài màn hình
- `FakePayConfig` – lưu `config/fakepay.json` (chỉ ghi khi đổi trạng thái)
- `FakePayMod` – entrypoint, phím mở bảng
